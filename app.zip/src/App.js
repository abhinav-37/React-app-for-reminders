import React from "react";
import { Button } from "react-bootstrap";
import "./App.css";
import { Reminder } from "./components/Reminder";

function App() {
    return (
        <div className="App">
            <Reminder />
        </div>
    );
}

export default App;
